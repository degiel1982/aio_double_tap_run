local dt_module = dofile(core.get_modpath("aio_api") .. "/api/double_tap_detection.lua")
local set_sprinting = dofile(core.get_modpath("aio_api") .. "/api/physics.lua")
local mod_storage = core.get_mod_storage() -- Use mod storage to save player flags persistently
local player_flags = {}
local pova_is_installed = core.get_modpath("pova") ~= nil

-- Load sprinting state from mod storage when the player joins
core.register_on_joinplayer(function(player, last_login)
    local player_name = player:get_player_name()
    local saved_can_sprint = mod_storage:get_int(player_name .. "_can_sprint") -- Load saved state
    if saved_can_sprint == 1 then
        player_flags[player_name] = { can_sprint = true }
    else
        player_flags[player_name] = { can_sprint = false }
    end
end)

-- Save sprinting state to mod storage when the player leaves
core.register_on_leaveplayer(function(player)
    local player_name = player:get_player_name()
    if player_flags[player_name] then
        mod_storage:set_int(player_name .. "_can_sprint", player_flags[player_name].can_sprint and 1 or 0) -- Save state
    end
    player_flags[player_name] = nil -- Clean up in-memory flags
end)

-- Callback to handle sprinting logic
dt_module.register_dt_data_callback(function(player, filtered_data, dtime)
    local player_name = player:get_player_name()

    -- Initialize player data if not present
    if not player_flags[player_name] then
        player_flags[player_name] = {
            can_sprint = true -- Default state
        }
    end

    -- Stop sprinting if the flag is set
    if not player_flags[player_name].can_sprint then
        set_sprinting(player, false, 0) -- Stop sprinting
        return
    end

    -- Sprinting logic
    if filtered_data.dt_detected then
        set_sprinting(player, true, 1) -- Enable sprinting
    elseif pova_is_installed and not filtered_data.dt_detected then
        set_sprinting(player, false, 1) -- Disable sprinting
    end
end)

-- Function to enable sprinting dynamically
local function allow_player_sprinting(player)
    local player_name = player:get_player_name()
    if not player_flags[player_name] then
        player_flags[player_name] = {}
    end
    player_flags[player_name].can_sprint = true
end

-- Function to disable sprinting dynamically
local function stop_player_sprinting(player)
    local player_name = player:get_player_name()
    if not player_flags[player_name] then
        player_flags[player_name] = {}
    end
    player_flags[player_name].can_sprint = false
end

return allow_player_sprinting, stop_player_sprinting