local dt_module = dofile(core.get_modpath("aio_api") .. "/api/double_tap_detection.lua")
local allow_sprint, stop_sprint = dofile(core.get_modpath("aio_api") .. "/api/sprinting.lua")

-- Use Mod Storage for saving stamina levels
local mod_storage = core.get_mod_storage()

--[[ GET MOD AUTHOR ]]
local function get_mod_author(modname)
    local modpath = core.get_modpath(modname)
    if not modpath then
        return nil, "Mod not found"
    end

    local mod_conf = Settings(modpath .. "/mod.conf")
    if not mod_conf then
        return nil, "mod.conf not found"
    end

    local author = mod_conf:get("author")
    if author then
        return author
    else
        return nil, "Author field not found in mod.conf"
    end
end

local mod_settings = {} -- Global settings
local stamina_is_installed = core.get_modpath("stamina") ~= nil
if stamina_is_installed then
    local mod_author = get_mod_author("stamina")
    if mod_author == "TenPlus1" then
        mod_settings.sprint_exhaust = tonumber(core.settings:get("stamina_sprint_drain")) or 0.35
        mod_settings.sprint_exhaust = mod_settings.sprint_exhaust * 100
        mod_settings.treshold = stamina.STARVE_LVL * 2
        stamina.enable_sprint = false
    elseif mod_author == "sofar" then
        mod_settings.sprint_exhaust = tonumber(core.settings:get("stamina.exhaust_sprint")) or 28
        mod_settings.sprint_exhaust = mod_settings.sprint_exhaust * 2
        mod_settings.treshold = tonumber(core.settings:get("stamina.starve_lvl")) or 3
        mod_settings.treshold = mod_settings.treshold * 2
    end
end


-- Save player's stamina to mod storage when they leave
core.register_on_leaveplayer(function(player)
    local player_name = player:get_player_name()
    local current_saturation = stamina.get_saturation(player) or 0 -- Fallback if nil
    mod_storage:set_int(player_name .. "_stamina", current_saturation) -- Save stamina level
end)

-- Restore player's stamina from mod storage when they join
core.register_on_joinplayer(function(player, last_login)
    local player_name = player:get_player_name()
    local saved_stamina = mod_storage:get_int(player_name .. "_stamina") or 0 -- Load saved stamina level

    -- Ensure the saved stamina is valid and compatible with the stamina mod
    if stamina.set_saturation then
        if saved_stamina and saved_stamina > 0 then
            stamina.change_saturation(player, saved_stamina) -- Restore stamina level
        else
            stamina.set_saturation(player, stamina.DEFAULT_SATURATION or 20) -- Set default value if none saved
        end
    else
        minetest.log("warning", "[aio_api] Stamina mod is not correctly initialized or compatible.")
    end
end)

-- Continuously monitor player's saturation and adjust sprinting state
core.register_globalstep(function(dtime)
    for _, player in ipairs(core.get_connected_players()) do
        local player_name = player:get_player_name()
        local current_saturation = stamina.get_saturation(player) or 0 -- Fallback if nil

        if current_saturation <= mod_settings.treshold then
            stop_sprint(player) -- Stop sprinting below threshold
        else
            allow_sprint(player) -- Allow sprinting above threshold
        end
    end
end)

-- Register callback for double-tap detection
dt_module.register_dt_data_callback(function(player, filtered_data, dtime)
    local player_name = player:get_player_name()
    local current_saturation = stamina.get_saturation(player) or 0 -- Fallback if nil

    if filtered_data.dt_detected then
        stamina.exhaust_player(player, (mod_settings.sprint_exhaust or 28) * dtime) -- Exhaust stamina
    end
end)