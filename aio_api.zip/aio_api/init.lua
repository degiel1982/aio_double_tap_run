dofile(core.get_modpath("aio_api") .. "/api/sprinting.lua")


--local stamina_is_installed = core.get_modpath("stamina") ~= nil
--if stamina_is_installed then
--    dofile(core.get_modpath("aio_api") .. "/api/stamina.lua")
--end