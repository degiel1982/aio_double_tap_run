local dt_module = {}

local dt_data = {}
local suppress_repeated_messages = false -- Default to suppress repeated messages

-- Helper to create a new player data copy
local function create_player_data()
    return {
        dt_detected = false,
        last_tap_time = 0,
        is_holding = false,
        aux_pressed = false, -- Track AUX key state
        key = "NO_KEY",
        last_sent_key = "NO_KEY" -- Track last sent message
    }
end

core.register_on_leaveplayer(function(player)
    local player_name = player:get_player_name()
    dt_data[player_name] = nil
end)

core.register_globalstep(function(dtime)
    local players = core.get_connected_players()
    local current_time = core.get_us_time() / 1000000 -- Convert microseconds to seconds

    for _, player in ipairs(players) do
        local player_name = player:get_player_name()

        if not dt_data[player_name] then
            dt_data[player_name] = create_player_data()
        end

        local player_control = player:get_player_control_bits()
        local player_data = dt_data[player_name]

        if player_control == 33 then  -- AUX + FORWARD KEY
            player_data.dt_detected = true
            player_data.is_holding = false
            player_data.aux_pressed = true
            player_data.key = "AUX1"
        elseif player_control == 1 then  -- FORWARD KEY only
            if not player_data.is_holding then
                if current_time - player_data.last_tap_time < 0.5 then
                    player_data.dt_detected = true
                    player_data.key = "FORWARD"
                end
                player_data.last_tap_time = current_time
                player_data.is_holding = true
            end
            -- If AUX was pressed earlier but now released, keep sprinting but mark AUX as released
            if player_data.aux_pressed then
                player_data.key = "FORWARD"
                player_data.aux_pressed = false
            end
        elseif player_control == 0 then  -- No key pressed
            player_data.dt_detected = false
            player_data.is_holding = false
            player_data.aux_pressed = false
            player_data.key = "NO_KEY"
        end

        -- Only send a message if the key state changes and suppression is enabled
        if not suppress_repeated_messages or (player_data.key ~= player_data.last_sent_key) then
            -- Invoke callbacks after processing player state
            dt_module.invoke_dt_data_callbacks(player, dtime)
            -- Update the last sent key
            player_data.last_sent_key = player_data.key
        end
    end
end)

--------------------------------------------------------------------------------
-- Configuration Mechanism
--------------------------------------------------------------------------------

-- Enable or disable repeated message suppression
function dt_module.set_suppress_repeated_messages(value)
    suppress_repeated_messages = value
end

--------------------------------------------------------------------------------
-- Callback Registration Mechanism
--------------------------------------------------------------------------------

-- This table will store all registered callback functions
local dt_data_callbacks = {}

-- Register a callback function to be called later with the filtered data
function dt_module.register_dt_data_callback(callback)
    table.insert(dt_data_callbacks, callback)
end

-- This function will invoke all registered callbacks for the given player
-- It retrieves the player's data, filters out unnecessary fields, and passes
-- the result to all callbacks
function dt_module.invoke_dt_data_callbacks(player, dtime)
    local player_name = player:get_player_name()
    local data = dt_data[player_name]
    if data then
        local filtered_data = {
            dt_detected = data.dt_detected,
            key = data.key,
            timer = dtime
        }
        for _, callback in ipairs(dt_data_callbacks) do
            callback(player, filtered_data, dtime)
        end
    end
end

-- Expose the module for use in other files
return dt_module