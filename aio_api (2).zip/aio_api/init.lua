local dt_module = dofile(core.get_modpath("aio_api") .. "/api/double_tap_detection.lua")
local allow_sprint, stop_sprint = dofile(core.get_modpath("aio_api") .. "/api/sprinting.lua")


--local stamina_is_installed = core.get_modpath("stamina") ~= nil
--if stamina_is_installed then
--    dofile(core.get_modpath("aio_api") .. "/api/stamina.lua")
--end