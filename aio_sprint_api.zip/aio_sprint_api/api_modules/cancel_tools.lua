local LIQUID_CHECK = core.settings:get_bool("aio_double_tap_run.liquid_check", false)
local WALL_CHECK = core.settings:get_bool("aio_double_tap_run.wall_check", false)
local CLIMBABLE_CHECK = core.settings:get_bool("aio_double_tap_run.climbable_check", false)

function aio_double_tap_run.player_is_in_liquid(pos)
    local feet_pos = { x = pos.x, y = pos.y - 0.5, z = pos.z }
    local head_pos = { x = pos.x, y = pos.y + 0.85, z = pos.z }
    local check_positions = { vector.round(feet_pos), vector.round(head_pos) }
    for _, p in ipairs(check_positions) do
        local node = core.get_node_or_nil(p)
        if node then
            local nodedef = core.registered_nodes[node.name]
            if nodedef and nodedef.liquidtype and nodedef.liquidtype ~= "none" then
                return true
            end
        end
    end
    return false
end

function aio_double_tap_run.is_player_on_climbable(player)
    local pos = player:get_pos()
    pos.y = pos.y - 0.5 
    local node = minetest.get_node_or_nil(pos)
    if node ~= nil then
        local nodedef = minetest.registered_nodes[node.name]
        return nodedef and nodedef.climbable or false
    else 
        return false
    end
end

function aio_double_tap_run.is_player_running_against_wall(player)
    local pos = player:get_pos()
    local dir = player:get_look_dir()
    
    -- Check a position slightly in front of the player
    local check_pos = { 
        x = pos.x + dir.x * 0.5, 
        y = pos.y, 
        z = pos.z + dir.z * 0.5 
    }
    local node = minetest.get_node_or_nil(vector.round(check_pos))
    
    if node then
        local nodedef = minetest.registered_nodes[node.name]
        -- Check if the node is solid (not walkable) to determine a wall
        return nodedef and nodedef.walkable or false
    else
        return false
    end
end

aio_double_tap_run.register_dt_data_callback(function(player, filtered_data, dtime)
    local player_name = player:get_player_name()
    local pos = player:get_pos()
    local control = player:get_player_control()    
    if LIQUID_CHECK then
        -- Check if the player is in liquid using their current position.
        local in_liquid = aio_double_tap_run.player_is_in_liquid(pos)
        if in_liquid then
            aio_double_tap_run.add_to_cancel_list(player_name, "WET_FEET")
        else
            aio_double_tap_run.remove_from_cancel_list(player_name)
        end
    end
    if CLIMBABLE_CHECK then
        -- Check if the player is standing on a climbable node.
        local on_climbable = aio_double_tap_run.is_player_on_climbable(player)
        if on_climbable then
            aio_double_tap_run.add_to_cancel_list(player_name, "ON_CLIMBABLE")
        else
            aio_double_tap_run.remove_from_cancel_list(player_name)
        end
    end
    if WALL_CHECK then
        -- Check if the player is running against a wall.
        local against_wall = aio_double_tap_run.is_player_running_against_wall(player)
        if against_wall then
            aio_double_tap_run.add_to_cancel_list(player_name, "WALL")
        else
            aio_double_tap_run.remove_from_cancel_list(player_name)
        end
    end
end)
