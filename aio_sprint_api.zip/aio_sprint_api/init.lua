local dt_module = dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/double_tap_trigger.lua")
local set_sprinting = dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/set_sprinting.lua")
local player_flags = {}
dt_module.register_dt_data_callback(function(player, filtered_data, dtime)
    local player_name = player:get_player_name()

    -- Initialize player data if not present
    if not player_flags[player_name] then
        player_flags[player_name] = {
            can_sprint = true -- Default state
        }
    end

    -- Stop sprinting if the flag is set
    if not player_flags[player_name].can_sprint then
        set_sprinting(player, false, 0) -- Stop sprinting
        return
    end

    -- Sprinting logic
    if filtered_data.dt_detected then
        set_sprinting(player, true, 1) -- Enable sprinting
    end
end)