aio_double_tap_run = {}
dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/cancel_tools.lua")
dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/set_sprinting.lua")
dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/double_tap_trigger.lua")

