aio_double_tap_run = {}

aio_double_tap_run.sprint_speed = tonumber(core.settings:get("aio_double_tap_run.extra_speed")) or 0.8 

dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/double_tap_trigger.lua")
dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/cancel_tools.lua")
dofile(core.get_modpath("aio_sprint_api") .. "/api_modules/set_sprinting.lua")

local SPRINT_STATES = {}

function aio_double_tap_run.get_sprint_state(player_name)
    return SPRINT_STATES[player_name] or false
end
function aio_double_tap_run.clear_sprint_state(player_name)
    SPRINT_STATES[player_name] = nil
end

aio_double_tap_run.register_dt_data_callback(function(player, filtered_data, dtime)
    local player_name = player:get_player_name()
    local control = player:get_player_control()

    if not SPRINT_STATES[player_name] then
        SPRINT_STATES[player_name] = {}
    end

    if filtered_data.dt_detected and filtered_data.key == "FORWARD" then
        aio_double_tap_run.set_sprinting(player, true, aio_double_tap_run.sprint_speed)
        SPRINT_STATES[player_name] = true
    elseif filtered_data.dt_detected and filtered_data.key == "AUX1" then
        aio_double_tap_run.set_sprinting(player, true, aio_double_tap_run.sprint_speed)
        SPRINT_STATES[player_name] = true
    elseif not filtered_data.dt_detected and filtered_data.key == "CANCELLED" then
        if SPRINT_STATES[player_name] then
            aio_double_tap_run.set_sprinting(player, false)
            SPRINT_STATES[player_name] = false
        end
    elseif not filtered_data.dt_detected and filtered_data.key == "NO_KEY" then
        if SPRINT_STATES[player_name] then
            aio_double_tap_run.set_sprinting(player, false)
            SPRINT_STATES[player_name] = false
        end
    end
end)


