Here’s an updated version that keeps the same style but is more user-friendly:

---

## **Features**

### **Core Features**
- **Double Tap Sprinting**: Activate sprinting by double-tapping the forward key—an intuitive and responsive way to move faster.
- **Fully-Fledged Sprinting Mod**: Designed with double-tap sprinting as its standout feature.
- **AUX1 Sprinting (Optional)**: When enabled, you can also sprint by holding the AUX1 key.
- **Smooth Sprinting Experience**: Enjoy uninterrupted sprinting without sudden cancellations (unless specified in the settings).

---

### **Compatibility with Stamina by Sofar and Stamina (Fork) by Tenplus1**

#### **What These Mods Add**
- **Stamina by Sofar**:
  - Tracks your stamina as you perform activities like walking, digging, fighting, or crafting.
  - Stamina must be replenished to regain health fully.
  - If stamina is completely depleted, players take damage over time.

- **Stamina (Fork) by Tenplus1**:
  - Adds hunger mechanics, making stamina decrease during activities or over time.
  - Enables sprinting using the AUX1 key, provided you have enough stamina.
  - Includes fun extras like drunk effects (after consuming alcohol) and poison counteractions (via milk).
  - Integrates seamlessly with popular mods such as 3D Armor, POVA, and Player Monoids.

- **Key Things to Keep in Mind**
    - **Sprint Speed**: Adjust sprint speed only through the Stamina mod's settings to ensure compatibility.
    - **AUX1 Sprinting**: Enable or disable the AUX1 sprinting option within the mod's settings.
    - **Sprint Particles**: Configure sprint particle effects through the Stamina mod's settings.
    - **Stamina Drain**: Toggle stamina drain only within the Stamina mod's settings.

