# API Documentation: `aio_double_tap_run.register_dt_data_callback(callback)`

## Overview
The function `aio_double_tap_run.register_dt_data_callback(callback)` registers a callback function that will be invoked with filtered double-tap (DT) data for a player. This allows you to customize how DT events are handled, processed, or logged as part of the sprinting and movement logic.

## Function Signature
```lua
aio_double_tap_run.register_dt_data_callback(callback)
```

## Parameters
- **`callback`** (function):  
  A function that will be called whenever DT data is processed for a player. The callback function should have the following signature:
  ```lua
  function(player, filtered_data, dtime)
      -- Custom logic here
  end
  ```
  - **`player`**: A player object representing the current player being processed.
  - **`filtered_data`**: A table containing the following keys:
    - `dt_detected` (boolean): Indicates whether a double tap has been detected.
    - `key` (string): Describes the key press type that triggered the DT detection (e.g., "FORWARD", "AUX1", etc.).
    - `timer` (number): The delta time (`dtime`) from the global step, reflecting the time frame of the event.
  - **`dtime`** (number): The delta time (in seconds) since the last global step. This value can be used for time-sensitive operations within the callback.

## Behavior
- The provided callback function is inserted into an internal list (`dt_data_callbacks`).
- During each global step, if DT data is available for a player, all registered callbacks are invoked using the current DT data.
- Multiple callbacks can be registered. They will be executed sequentially in the order they were added.

## Example Usage
```lua
-- Define a custom callback function to handle double tap events
local function onDoubleTap(player, filtered_data, dtime)
    if filtered_data.dt_detected then
        local player_name = player:get_player_name()
        print("Double tap detected for player: " .. player_name)
        print("Triggered key: " .. filtered_data.key)
        print("dtime value: " .. dtime)
        -- Additional custom logic can go here
    end
end

-- Register the callback with the system
aio_double_tap_run.register_dt_data_callback(onDoubleTap)
```

## Remarks
- **Pre-requisites:** Ensure that the callback function is defined before registering it.
- **Multiple Callbacks:** You can register more than one callback, allowing you to extend or override behavior as needed.
- **Execution Context:** The callbacks run during the global step, so they should perform lightweight operations to avoid performance issues.
- **Use Case:** This mechanism is ideal for integrating additional behavior when a double tap is detected, such as triggering animations, logging events, or modifying player states.

---

This documentation provides a comprehensive view of the `register_dt_data_callback` API function, its purpose, parameters, expected behavior, and usage examples.
``` 

--- 

If you need further exploration into customizing double-tap event responses or insights into other parts of the API, feel free to ask!